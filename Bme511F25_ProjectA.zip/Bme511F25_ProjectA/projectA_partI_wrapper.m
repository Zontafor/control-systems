%% projectA_partI_wrapper.m
% Project A - Part I Step Response Simulation (Assignment Cases)
% Author: Michelle L. Wu
% Course: BME 511 - Physiological Control Systems
% Runs Cases (a)–(e) from the Part I, Question 1 handout for
% nmreflex_2025.slx and saves the step-response figure and data.

clear; clc;

%% Load default parameters and define paths
run('nmr_var_2025.m');   % loads J, B, k, beta, eta, Td, tau

% Store defaults explicitly
J0    = J;
B0    = B;
k0    = k;
beta0 = beta;
Td0   = Td;

dataDir = '/Users/mlwu/Documents/Academia/USC/BME/511/project/Bme511F25_ProjectA/data';
figDir  = '/Users/mlwu/Documents/Academia/USC/BME/511/project/Bme511F25_ProjectA/data/figs';
if ~exist(dataDir, 'dir'); mkdir(dataDir); end
if ~exist(figDir,  'dir'); mkdir(figDir);  end

%% Step input settings (used by Step block inside nmreflex_2025)
stepAmplitude = 5;  % Nm
stepTime      = 0;  % s

modelName = 'nmreflex_2025';

%% Define assignment cases (exactly as in Part I–Q1)
cases_param = {
    struct('J',J0, 'B',B0, 'k',k0,   'beta',beta0,   'Td',Td0,    ...
           'label','(a) default')
    struct('J',J0, 'B',B0, 'k',k0,   'beta',200,     'Td',Td0,    ...
           'label','(b) \beta = 200')
    struct('J',J0, 'B',B0, 'k',k0,   'beta',0,       'Td',Td0,    ...
           'label','(c) \beta = 0 (open loop)')
    struct('J',J0, 'B',B0, 'k',k0,   'beta',beta0,   'Td',0.04,   ...
           'label','(d) T_d = 0.04 s')
    struct('J',J0, 'B',B0, 'k',100,  'beta',beta0,   'Td',Td0,    ...
           'label','(e) k = 100 N·m')
};

%% Truncate signals to common length for a single case
truncate = @(t,x,y) deal( ...
    t(1:min([numel(t), numel(x), numel(y)])), ...
    x(1:min([numel(t), numel(x), numel(y)])), ...
    y(1:min([numel(t), numel(x), numel(y)])) );

%% Run simulations for all cases
results = struct();  % results.case_a, results.case_b, ...

warning('off','Simulink:blocks:DerivativeInputNotDifferentiable');
warning('off','Simulink:Engine:DerivInfOrNaN');

figure('Color','w'); hold on; grid on;

for i = 1:numel(cases_param)
    ci = cases_param{i};

    % Push parameter values into base workspace for Simulink
    assignin('base','J',    ci.J);
    assignin('base','B',    ci.B);
    assignin('base','k',    ci.k);
    assignin('base','beta', ci.beta);
    assignin('base','Td',   ci.Td);
    assignin('base','stepAmplitude', stepAmplitude);
    assignin('base','stepTime',      stepTime);

    % Simulate and retrieve logged outputs
    simOut = sim(modelName, 'ReturnWorkspaceOutputs', 'on');

    t     = simOut.t;
    theta = simOut.theta;
    Mx    = simOut.Mx;

    [t_i, theta_i, Mx_i] = truncate(t, theta, Mx);

    % Store in results structure
    caseName = sprintf('case_%s', char(96+i));  % case_a, case_b, ...
    results.(caseName).label = ci.label;
    results.(caseName).J     = ci.J;
    results.(caseName).B     = ci.B;
    results.(caseName).k     = ci.k;
    results.(caseName).beta  = ci.beta;
    results.(caseName).Td    = ci.Td;
    results.(caseName).t     = t_i;
    results.(caseName).theta = theta_i;
    results.(caseName).Mx    = Mx_i;

    % Plot theta(t) for this case
    plot(t_i, theta_i, 'LineWidth', 1.2, 'DisplayName', ci.label);
end

xlabel('Time (s)');
ylabel('\theta(t) [rad]');
% title('Step Responses for Cases (a)–(e)');
legend('Location','northwest');

% Save figure
figName = fullfile(figDir, 'ProjectA_PartI_StepResponses.png');
exportgraphics(gcf, figName, 'Resolution', 300);
fprintf('Figure saved to: %s\n', figName);

%% Attach global parameter metadata and save MAT
results.params = struct('J_default',J0, 'B_default',B0, 'k_default',k0, ...
                        'beta_default',beta0, 'Td_default',Td0, ...
                        'eta',eta, 'tau',tau);

matFile = fullfile(dataDir, 'ProjectA_PartI_Data.mat');
save(matFile, '-struct', 'results');
fprintf('Data saved:   %s\n', matFile);

%% Export combined CSV for LaTeX
caseNames = fieldnames(results);
caseNames = caseNames(startsWith(caseNames,'case_'));  % exclude 'params'

Case  = [];
Time  = [];
Theta = [];
Mx_all = [];

for i = 1:numel(caseNames)
    ci = results.(caseNames{i});
    n  = numel(ci.t);
    Case   = [Case;   repmat(string(ci.label), n, 1)];
    Time   = [Time;   ci.t(:)];
    Theta  = [Theta;  ci.theta(:)];
    Mx_all = [Mx_all; ci.Mx(:)];
end

T = table(Case, Time, Theta, Mx_all, ...
          'VariableNames', {'Case','Time_s','Theta_rad','Mx_Nm'});

csvFile = fullfile(dataDir, 'ProjectA_PartI_StepResponses.csv');
writetable(T, csvFile);
fprintf('CSV saved:    %s\n', csvFile);

warning('on','Simulink:blocks:DerivativeInputNotDifferentiable');
warning('on','Simulink:Engine:DerivInfOrNaN');