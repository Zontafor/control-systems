%% projectA_partI_step.m
% BME 511 Project A -- Part I step-response analysis
% This script assumes that nmreflex_2025.slx logs the joint angle theta(t)
% and external torque Mx(t) to the workspace as variables named 't', 'theta',
% and 'Mx'. Uses post-simulation data capture for parameter studies.

clear; clc;
warning('off','Simulink:blocks:DerivativeInputNotDifferentiable');
warning('off','Simulink:Engine:DerivInfOrNaN');

%% Set paths for saving outputs
projectRoot = pwd;  % adjust if you prefer a fixed path
dataDir = fullfile(projectRoot, 'data');
figDir  = fullfile(dataDir, 'figs');

if ~exist(dataDir, 'dir'); mkdir(dataDir); end
if ~exist(figDir,  'dir'); mkdir(figDir);  end

%% Base parameters and step settings
run('nmr_var_2025.m');     % load default parameters

stepAmplitude = 5;         % Nm (used by Step block inside nmreflex_2025)
stepTime      = 0;         % s

modelName = 'nmreflex_2025';

cases = struct();          % initialize structure to hold all results

%% Helper inline function for truncation
truncate = @(t,x,y) deal( ...
    t(1:min([numel(t), numel(x), numel(y)])), ...
    x(1:min([numel(t), numel(x), numel(y)])), ...
    y(1:min([numel(t), numel(x), numel(y)])) );

%% (1a) Default parameter values
run('nmr_var_2025.m');     % reset defaults
sim(modelName);            % run model

[t_a, theta_a, Mx_a] = truncate(t, theta, Mx);
cases.a.label = '(a) default';
cases.a.t     = t_a;
cases.a.theta = theta_a;
cases.a.Mx    = Mx_a;

%% (1b) Increased feedback gain beta = 200
run('nmr_var_2025.m');
beta = 200;
sim(modelName);

[t_b, theta_b, Mx_b] = truncate(t, theta, Mx);
cases.b.label = '(b) \beta = 200';
cases.b.t     = t_b;
cases.b.theta = theta_b;
cases.b.Mx    = Mx_b;

%% (1c) Open-loop (beta = 0)
run('nmr_var_2025.m');
beta = 0;
sim(modelName);

[t_c, theta_c, Mx_c] = truncate(t, theta, Mx);
cases.c.label = '(c) \beta = 0 (open loop)';
cases.c.t     = t_c;
cases.c.theta = theta_c;
cases.c.Mx    = Mx_c;

%% (1d) Increased reflex delay Td = 0.04 s
run('nmr_var_2025.m');
Td = 0.04;
sim(modelName);

[t_d, theta_d, Mx_d] = truncate(t, theta, Mx);
cases.d.label = '(d) T_d = 0.04 s';
cases.d.t     = t_d;
cases.d.theta = theta_d;
cases.d.Mx    = Mx_d;

%% (1e) Increased muscle stiffness k = 100 N·m
run('nmr_var_2025.m');
k = 100;
sim(modelName);

[t_e, theta_e, Mx_e] = truncate(t, theta, Mx);
cases.e.label = '(e) k = 100 N·m';
cases.e.t     = t_e;
cases.e.theta = theta_e;
cases.e.Mx    = Mx_e;

%% Overlay plot of all step responses theta(t)
figure('Color','w');
hold on;
fn = fieldnames(cases);
for i = 1:numel(fn)
    ci = cases.(fn{i});
    plot(ci.t, ci.theta, 'DisplayName', ci.label, 'LineWidth', 1.2);
end
xlabel('Time (s)');
ylabel('\theta(t) (rad)');
title('Step Responses for Parameter Variations (Cases (a)–(e))');
legend('Location','southeast');
grid on;
hold off;

% Save figure
figPath = fullfile(figDir, 'ProjectA_PartI_StepResponses.png');
print(gcf, figPath, '-dpng', '-r300');
fprintf('Step-response figure saved to: %s\n', figPath);

%% Save numerical data (MAT + CSV)
matPath = fullfile(dataDir, 'ProjectA_PartI_Data.mat');
save(matPath, 'cases');
fprintf('Step-response data saved to: %s\n', matPath);

% Flatten structure into a table for quick inspection / grading
Case  = [];
Time  = [];
Theta = [];
Mx_all = [];
for i = 1:numel(fn)
    ci = cases.(fn{i});
    n  = numel(ci.t);
    Case  = [Case;  repmat(string(ci.label), n, 1)];
    Time  = [Time;  ci.t(:)];
    Theta = [Theta; ci.theta(:)];
    Mx_all = [Mx_all; ci.Mx(:)];
end
T = table(Case, Time, Theta, Mx_all, ...
          'VariableNames', {'Case','Time_s','Theta_rad','Mx_Nm'});

csvPath = fullfile(dataDir, 'ProjectA_PartI_StepResponses.csv');
writetable(T, csvPath);
fprintf('Step-response CSV saved to: %s\n', csvPath);

%% Restore warnings
warning('on','Simulink:blocks:DerivativeInputNotDifferentiable');
warning('on','Simulink:Engine:DerivInfOrNaN');