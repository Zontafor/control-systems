%% nmr_var_2025.m
% Parameter file for BME 511 Project A neuromuscular reflex model.
% Run this script before simulating nmreflex_2025.slx so that all
% parameters are available in the base workspace.
% J=0.1;
% k=50;
% B=2;
% Td=0.02;
% tau=1/300;
% eta=5;
% beta=50;

% Forearm or lower-leg inertia about the joint (kg*m^2)
J = 0.1;

% Muscle stiffness parameter (N*m)
k = 50;

% Viscous damping coefficient (N*m*s)
B = 2;

% Neuromuscular reflex delay (s)
Td = 0.02;

% Muscle spindle time constant (s)
tau = 1/300;

% Ratio between total spring stiffness and parallel element stiffness
eta = 5;

% Feedback gain from muscle spindles (dimensionless)
% Default value can be changed for different simulation scenarios.
beta = 50;


