%% projectA_partI_freqresp.m
% BME 511 Project A -- Part I frequency-response estimation
% Computes empirical gain and phase from steady-state sinusoidal
% responses. For each frequency f (Hz), assumes a MAT-file
%   nmreflex_sine_fHz.mat
% exists in the data directory with variables:
%   t  - time vector (s)
%   Mx - input torque (Nm)
%   theta - output angle (rad)

clear; clc;

%% Paths and frequency grid
projectRoot = pwd;
dataDir = fullfile(projectRoot, 'data');
if ~exist(dataDir, 'dir')
    error('Data directory not found: %s', dataDir);
end

freqs = [1 2 3 4 5];     % Hz

% Preallocate arrays for gain and phase
G   = zeros(size(freqs));   % magnitude
phi = zeros(size(freqs));   % radians

%% Loop over frequencies
for kf = 1:numel(freqs)
    f = freqs(kf);
    fname = sprintf('nmreflex_sine_%gHz.mat', f);
    fpath = fullfile(dataDir, fname);

    if ~isfile(fpath)
        error('Expected data file not found: %s', fpath);
    end

    data = load(fpath);   % expects t, Mx, theta

    t     = data.t(:);
    Mx    = data.Mx(:);
    theta = data.theta(:);

    % Remove transients: discard first 3 periods
    T  = 1/f;
    tMin = t(1) + 3*T;
    idx_ss = t >= tMin;
    t_ss     = t(idx_ss);
    Mx_ss    = Mx(idx_ss);
    theta_ss = theta(idx_ss);

    % Estimate amplitudes via peak-to-peak method
    A_Mx    = (max(Mx_ss)    - min(Mx_ss))    / 2;
    A_theta = (max(theta_ss) - min(theta_ss)) / 2;
    G(kf)   = A_theta / A_Mx;

    % Estimate phase via time lag between first peaks in steady state
    [~, iMx] = max(Mx_ss);
    tMx_peak = t_ss(iMx);

    [~, ith] = max(theta_ss);
    tth_peak = t_ss(ith);

    dt = tth_peak - tMx_peak;      % time shift (s)
    phi(kf) = -2*pi*f*dt;          % phase (rad), negative for lag
end

% Convert phase to degrees
phi_deg = phi * 180/pi;

%% Plot gain vs frequency
figure('Color','w');
semilogx(freqs, G, 'o-','LineWidth',1.2);
xlabel('Frequency (Hz)');
ylabel('Gain |\theta/M_x|');
title('Empirical Frequency Response: Gain');
grid on;

%% Plot phase vs frequency
figure('Color','w');
semilogx(freqs, phi_deg, 'o-','LineWidth',1.2);
xlabel('Frequency (Hz)');
ylabel('Phase (degrees)');
title('Empirical Frequency Response: Phase');
grid on;

%% Save gain/phase data
freqRespPath = fullfile(dataDir, 'ProjectA_PartI_FreqResponse.mat');
save(freqRespPath, 'freqs', 'G', 'phi', 'phi_deg');
fprintf('Frequency-response data saved to: %s\n', freqRespPath);