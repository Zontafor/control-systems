%% projectA_partII_kneejerk.m
%  Author: Michelle L. Wu
%  Course: BME 511 – Physiological Control Systems
%  Part II: Knee-jerk (stretch-reflex) response
%  Compares a normal subject vs. a patient with exaggerated reflex
%  (increased stiffness k, reflex gain beta, and neural delay Td).

clear; clc;

%% Load baseline neuromuscular parameters
run('nmr_var_2025.m');   % loads J, B, k, beta, Td, tau, eta, etc.

% Store defaults
J_default    = J;
beta_default = beta;
k_default    = k;
Td_default   = Td;

%% Override inertia with lower-leg value
J_leg = 0.25;        % kg·m^2 about knee
J = J_leg;
assignin('base','J',J);

%% Output directories
dataDir = '/Users/mlwu/Documents/Academia/USC/BME/511/project/Bme511F25_ProjectA/data';
figDir  = '/Users/mlwu/Documents/Academia/USC/BME/511/project/Bme511F25_ProjectA/data/figs';
if ~exist(figDir,'dir');  mkdir(figDir);  end
if ~exist(dataDir,'dir'); mkdir(dataDir); end

%% Normal vs. patient parameter sets
beta_normal = beta_default;
k_normal    = k_default;
Td_normal   = Td_default;

beta_patient = 1.5 * beta_normal;
k_patient    = 1.5 * k_normal;
Td_patient   = 1.5 * Td_normal;

cases(1) = struct('label','Normal',  ...
                  'beta',beta_normal,  'k',k_normal,  'Td',Td_normal);
cases(2) = struct('label','Patient', ...
                  'beta',beta_patient, 'k',k_patient, 'Td',Td_patient);

modelName = 'nmreflex_2025';
simTime   = 1.0;   % s

results = struct();

for i = 1:numel(cases)
    ci = cases(i);

    % Push reflex parameters into base workspace
    assignin('base','beta', ci.beta);
    assignin('base','k',    ci.k);
    assignin('base','Td',   ci.Td);

    simOut = sim(modelName, ...
                 'StopTime', num2str(simTime), ...
                 'ReturnWorkspaceOutputs','on');

    results(i).label = ci.label;
    results(i).t     = simOut.t(:);
    results(i).theta = simOut.theta(:);   % extension < 0
end

%% Align and extract
minLen = min([numel(results(1).t), numel(results(1).theta), ...
              numel(results(2).t), numel(results(2).theta)]);

t_normal      = results(1).t(1:minLen);
theta_normal  = results(1).theta(1:minLen);
t_patient     = results(2).t(1:minLen);
theta_patient = results(2).theta(1:minLen);

%% Plot
figure('Color','w');
plot(t_normal,  theta_normal, 'b',  'LineWidth', 1.3); hold on;
plot(t_patient, theta_patient,'r--','LineWidth', 1.3);
xlabel('Time (s)');
ylabel('\theta(t) [rad]');  % theta < 0 = extension
title('Knee-Jerk Reflex: Normal vs. Patient');
legend('Normal','Patient','Location','northeast');
grid on; box on;

figFile = fullfile(figDir,'ProjectA_PartII_KneeJerk.png');
exportgraphics(gcf, figFile, 'Resolution', 300);

T = table(t_normal, theta_normal, t_patient, theta_patient, ...
          'VariableNames', {'t_normal_s','theta_normal_rad', ...
                           't_patient_s','theta_patient_rad'});
csvFile = fullfile(dataDir,'ProjectA_PartII_KneeJerk.csv');
writetable(T, csvFile);

matFile = fullfile(dataDir,'ProjectA_PartII_KneeJerk.mat');
save(matFile, ...
     't_normal','theta_normal','t_patient','theta_patient', ...
     'beta_normal','beta_patient','k_normal','k_patient', ...
     'Td_normal','Td_patient','J_leg','J_default');

fprintf('Knee-jerk figure saved to %s\n', figFile);
fprintf('Knee-jerk data saved to   %s\n', dataDir);